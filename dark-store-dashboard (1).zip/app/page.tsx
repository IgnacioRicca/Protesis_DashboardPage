"use client"

import DarkStoreDashboard from "../dark-store-dashboard"

export default function Page() {
  return <DarkStoreDashboard />
}
