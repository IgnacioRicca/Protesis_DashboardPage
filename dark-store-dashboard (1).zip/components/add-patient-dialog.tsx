"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Plus, X } from "lucide-react"

interface AddPatientDialogProps {
  onAddPatient: (patient: {
    name: string
    age: number
    prostheses: string[]
    status: "stable" | "warning" | "moving"
    lastVisit: string
    clinicalHistory: string
  }) => void
}

export function AddPatientDialog({ onAddPatient }: AddPatientDialogProps) {
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    clinicalHistory: "",
  })
  const [prostheses, setProstheses] = useState<string[]>([""])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name || !formData.age || !formData.clinicalHistory) {
      alert("Por favor complete todos los campos")
      return
    }

    const validProstheses = prostheses.filter((p) => p.trim() !== "")
    if (validProstheses.length === 0) {
      alert("Por favor agregue al menos un tipo de prótesis")
      return
    }

    if (!/^\d{6,7}$/.test(formData.clinicalHistory)) {
      alert("La historia clínica debe ser un número de 6 o 7 dígitos")
      return
    }

    const currentDate = new Date().toISOString().split("T")[0]

    onAddPatient({
      name: formData.name,
      age: Number.parseInt(formData.age),
      prostheses: validProstheses,
      status: "stable",
      lastVisit: currentDate,
      clinicalHistory: formData.clinicalHistory,
    })

    // Reset form
    setFormData({
      name: "",
      age: "",
      clinicalHistory: "",
    })
    setProstheses([""])
    setOpen(false)
  }

  const addProsthesis = () => {
    setProstheses([...prostheses, ""])
  }

  const removeProsthesis = (index: number) => {
    if (prostheses.length > 1) {
      setProstheses(prostheses.filter((_, i) => i !== index))
    }
  }

  const updateProsthesis = (index: number, value: string) => {
    const newProstheses = [...prostheses]
    newProstheses[index] = value
    setProstheses(newProstheses)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full bg-transparent" size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Agregar Paciente
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Agregar Nuevo Paciente</DialogTitle>
          <DialogDescription>Complete la información del paciente para agregarlo al sistema.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Nombre Completo</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Ej: Juan Pérez"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="age">Edad</Label>
              <Input
                id="age"
                type="number"
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                placeholder="Ej: 45"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="clinicalHistory">Historia Clínica</Label>
              <Input
                id="clinicalHistory"
                type="text"
                value={formData.clinicalHistory}
                onChange={(e) => setFormData({ ...formData, clinicalHistory: e.target.value })}
                placeholder="Ej: 123456"
                maxLength={7}
              />
            </div>
            <div className="grid gap-2">
              <div className="flex items-center justify-between">
                <Label>Tipo de Prótesis</Label>
                <Button type="button" variant="ghost" size="sm" onClick={addProsthesis}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              {prostheses.map((prosthesis, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={prosthesis}
                    onChange={(e) => updateProsthesis(index, e.target.value)}
                    placeholder="Ej: Prótesis de Rodilla"
                  />
                  {prostheses.length > 1 && (
                    <Button type="button" variant="ghost" size="sm" onClick={() => removeProsthesis(index)}>
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit">Agregar Paciente</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
