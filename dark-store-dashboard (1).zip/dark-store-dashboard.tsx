"use client"

import { useState, useEffect } from "react"
import { Bell } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
  SidebarInset,
} from "@/components/ui/sidebar"

import { ProfileCard } from "./components/profile-card"
import { PatientList } from "./components/patient-list"
import { PatientChart } from "./components/patient-chart"

const mockDoctor = {
  name: "Dra. Sarah Johnson",
  role: "doctor" as const,
  email: "sarah.johnson@hospital.com",
  phone: "+1 (555) 123-4567",
  avatar: "/placeholder.svg?height=80&width=80",
  specialization: "Cardiología",
}

const initialMockPatients = [
  {
    id: "P001",
    name: "Juan Smith",
    age: 45,
    prostheses: ["Prótesis de Rodilla"],
    status: "stable" as const,
    lastVisit: "2024-01-15",
    clinicalHistory: "123456",
  },
  {
    id: "P002",
    name: "Emma Davis",
    age: 32,
    prostheses: ["Prótesis de Cadera", "Prótesis de Rodilla"],
    status: "warning" as const,
    lastVisit: "2024-01-14",
    clinicalHistory: "234567",
  },
  {
    id: "P003",
    name: "Michael Brown",
    age: 58,
    prostheses: ["Prótesis de Hombro"],
    status: "moving" as const,
    lastVisit: "2024-01-16",
    clinicalHistory: "345678",
  },
  {
    id: "P004",
    name: "Lisa Wilson",
    age: 41,
    prostheses: ["Prótesis de Tobillo"],
    status: "stable" as const,
    lastVisit: "2024-01-13",
    clinicalHistory: "456789",
  },
]

const sampleChartData1 = [
  { x: 0, y: 2.1 },
  { x: 1, y: 2.3 },
  { x: 2, y: 1.9 },
  { x: 3, y: 2.5 },
  { x: 4, y: 2.2 },
  { x: 5, y: 2.0 },
  { x: 6, y: 2.4 },
]

const sampleChartData2 = [
  { x: 0, y: 15.2 },
  { x: 1, y: 14.8 },
  { x: 2, y: 16.1 },
  { x: 3, y: 15.5 },
  { x: 4, y: 14.9 },
  { x: 5, y: 15.8 },
  { x: 6, y: 15.3 },
]

type Notification = {
  id: string
  message: string
  timestamp: string
  read: boolean
}

export default function DarkStoreDashboard() {
  const [dateRange, setDateRange] = useState("today")
  const [selectedPatientId, setSelectedPatientId] = useState<string | undefined>(undefined)
  const [patients, setPatients] = useState(initialMockPatients)
  const [selectedProsthesis, setSelectedProsthesis] = useState<string>("")
  const [notifications, setNotifications] = useState<Notification[]>([])

  const userRole: "doctor" | "patient" = "doctor"

  const selectedPatient = patients.find((p) => p.id === selectedPatientId)

  if (selectedPatient && !selectedProsthesis && selectedPatient.prostheses.length > 0) {
    setSelectedProsthesis(selectedPatient.prostheses[0])
  }

  if (selectedPatient && selectedProsthesis && !selectedPatient.prostheses.includes(selectedProsthesis)) {
    setSelectedProsthesis(selectedPatient.prostheses[0] || "")
  }

  const handleAddPatient = (newPatient: Omit<(typeof initialMockPatients)[0], "id">) => {
    const newId = `P${String(patients.length + 1).padStart(3, "0")}`
    setPatients([...patients, { ...newPatient, id: newId }])
  }

  const sendEmailNotification = async (patientName: string, newStatus: string) => {
    console.log("[v0] Sending email notification to:", mockDoctor.email)
    console.log("[v0] Patient:", patientName, "Status changed to:", newStatus)

    // In a real application, this would call an API endpoint to send the email
    try {
      // Example API call:
      // await fetch('/api/send-notification', {
      //   method: 'POST',
      //   body: JSON.stringify({
      //     to: mockDoctor.email,
      //     subject: `Alerta: Cambio de estado del paciente ${patientName}`,
      //     message: `El estado del paciente ${patientName} ha cambiado a ${newStatus}`
      //   })
      // })

      // Add notification to the bell
      const newNotification: Notification = {
        id: Date.now().toString(),
        message: `El paciente ${patientName} cambió a estado ${newStatus}`,
        timestamp: new Date().toLocaleString("es-ES"),
        read: false,
      }
      setNotifications((prev) => [newNotification, ...prev])
    } catch (error) {
      console.error("[v0] Error sending notification:", error)
    }
  }

  useEffect(() => {
    // This would typically monitor real-time data changes
    // For demo purposes, we'll check when a patient's status changes to warning or moving
    patients.forEach((patient) => {
      if (patient.status === "warning" || patient.status === "moving") {
        // In a real app, you'd track previous states and only notify on actual changes
        // For now, this is a placeholder for the notification logic
      }
    })
  }, [patients])

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) => prev.map((notif) => (notif.id === id ? { ...notif, read: true } : notif)))
  }

  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <Sidebar>
          <SidebarHeader className="border-b px-6 py-4">
            <div className="flex items-center justify-center">
              <img src="/hospital-logo.png" alt="Hospital Universitario Austral" className="h-12 w-auto" />
            </div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupContent>
                <ProfileCard user={mockDoctor} />
              </SidebarGroupContent>
            </SidebarGroup>

            {userRole === "doctor" && (
              <SidebarGroup>
                <SidebarGroupContent>
                  <PatientList
                    patients={patients}
                    selectedPatientId={selectedPatientId}
                    onPatientSelect={setSelectedPatientId}
                    onAddPatient={handleAddPatient}
                  />
                </SidebarGroupContent>
              </SidebarGroup>
            )}
          </SidebarContent>
        </Sidebar>

        <SidebarInset className="flex-1">
          <header className="flex h-16 items-center justify-between border-b px-6">
            <div className="flex items-center space-x-4">
              <SidebarTrigger />
              <div>
                <h1 className="text-2xl font-bold">
                  {selectedPatient ? `Paciente: ${selectedPatient.name}` : "Panel de Pacientes"}
                </h1>
                <p className="text-sm text-muted-foreground">
                  {selectedPatient
                    ? `${selectedProsthesis || selectedPatient.prostheses[0]} - ${selectedPatient.status === "stable" ? "Estable" : selectedPatient.status === "warning" ? "Advertencia" : "Movimiento"}`
                    : "Seleccione un paciente para ver los detalles"}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm" className="relative bg-transparent">
                    <Bell className="w-4 h-4" />
                    {unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                        {unreadCount}
                      </span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80" align="end">
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Notificaciones</h4>
                    {notifications.length === 0 ? (
                      <p className="text-sm text-muted-foreground py-4 text-center">No hay notificaciones</p>
                    ) : (
                      <div className="space-y-2 max-h-96 overflow-y-auto">
                        {notifications.map((notification) => (
                          <div
                            key={notification.id}
                            className={`p-3 rounded-lg border ${
                              notification.read ? "bg-background" : "bg-muted"
                            } cursor-pointer hover:bg-accent transition-colors`}
                            onClick={() => markNotificationAsRead(notification.id)}
                          >
                            <p className="text-sm">{notification.message}</p>
                            <p className="text-xs text-muted-foreground mt-1">{notification.timestamp}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          </header>

          <main className="flex-1 p-6 space-y-6">
            {selectedPatient ? (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Historia Clínica del Paciente</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{selectedPatient.clinicalHistory}</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Prótesis</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {selectedPatient.prostheses.length > 1 ? (
                        <div className="space-y-2">
                          <Tabs value={selectedProsthesis} onValueChange={setSelectedProsthesis} className="w-full">
                            <TabsList
                              className="grid w-full"
                              style={{ gridTemplateColumns: `repeat(${selectedPatient.prostheses.length}, 1fr)` }}
                            >
                              {selectedPatient.prostheses.map((prosthesis, index) => (
                                <TabsTrigger key={index} value={prosthesis} className="text-xs">
                                  {index + 1}
                                </TabsTrigger>
                              ))}
                            </TabsList>
                          </Tabs>
                          <div className="text-sm font-medium break-words">{selectedProsthesis}</div>
                        </div>
                      ) : (
                        <div className="text-xl font-bold break-words">{selectedPatient.prostheses[0]}</div>
                      )}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Estado</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div
                        className={`text-xl font-bold capitalize break-words ${
                          selectedPatient.status === "stable"
                            ? "text-green-600"
                            : selectedPatient.status === "warning"
                              ? "text-orange-500"
                              : "text-red-600"
                        }`}
                      >
                        {selectedPatient.status === "stable"
                          ? "Estable"
                          : selectedPatient.status === "warning"
                            ? "Advertencia"
                            : "Movimiento"}
                      </div>
                      <p className="text-xs text-muted-foreground">Condición actual</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Última Medición</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{selectedPatient.lastVisit}</div>
                      <p className="text-xs text-muted-foreground">Última vez que se revisaron los datos</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex justify-center">
                  <Tabs value={dateRange} onValueChange={setDateRange} className="w-auto">
                    <TabsList>
                      <TabsTrigger value="today">Hoy</TabsTrigger>
                      <TabsTrigger value="yesterday">Ayer</TabsTrigger>
                      <TabsTrigger value="7days">7 días</TabsTrigger>
                      <TabsTrigger value="30days">30 días</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Aceleración</CardTitle>
                      <CardDescription>Mediciones en m/s² - {selectedProsthesis}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <PatientChart data={sampleChartData1} xLabel="Segundos" yLabel="m/s²" color="#3b82f6" />
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Micromovimientos</CardTitle>
                      <CardDescription>Mediciones en micrómetros (μm) - {selectedProsthesis}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <PatientChart data={sampleChartData2} xLabel="Segundos" yLabel="μm" color="#10b981" />
                    </CardContent>
                  </Card>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-96">
                <div className="text-center space-y-2">
                  <h3 className="text-xl font-semibold text-muted-foreground">Ningún Paciente Seleccionado</h3>
                  <p className="text-sm text-muted-foreground">
                    Seleccione un paciente de la barra lateral para ver sus datos médicos
                  </p>
                </div>
              </div>
            )}
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}
